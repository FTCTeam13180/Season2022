package Solution;

public class MovementEssentials {
}
