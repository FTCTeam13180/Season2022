package RobotUtilities;

public class MovementVars {
    public static double movement_x = 0;
    public static double movement_y = 0;
    public static double movement_turn = 0;
}
