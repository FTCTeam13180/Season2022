package treamcode;

public abstract class OpMode {

    public abstract void init();
    public abstract void loop();
}
